package com.example.senai;

import java.util.ArrayList;
import java.util.List;

public class Comida {

    private int id;
    private String nome;
    private String preço;
    private String descricao;

    private List<Comida> c = new ArrayList<>();

    public Comida(String nome, String preço, String descricao) {
        this.nome = nome;
        this.preço = preço;
        this.descricao = descricao;
    }

    public Comida() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getPreço() {
        return preço;
    }

    public void setPreço(String preço) {
        this.preço = preço;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    @Override
    public String toString() {
        return getNome() + "\n " + getPreço();
    }
}
