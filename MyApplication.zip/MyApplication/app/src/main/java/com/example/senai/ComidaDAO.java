package com.example.senai;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;

public class ComidaDAO {

    private Conexao conexao;
    private SQLiteDatabase banco;

    public ComidaDAO(Context context){
        conexao = new Conexao(context);

        banco = conexao.getWritableDatabase();
    }

    public long Inserir(Comida comida){
        ContentValues values = new ContentValues();
        values.put("nome", comida.getNome());
        values.put("preco", comida.getPreço());
        values.put("descricao", comida.getDescricao());

        return banco.insert("comidas", null, values);
    }

    public List<Comida> obterTodos(){
        List<Comida> comidas = new ArrayList<>();
        Cursor cursor = banco.query("comidas", new String[]{"id", "nome", "preco", "descricao"}, null, null, null, null, null);
        while (cursor.moveToNext()){
            Comida c = new Comida();
            c.setId(cursor.getInt(0));
            c.setNome(cursor.getString(1));
            c.setPreço(cursor.getString(2));
            c.setDescricao(cursor.getString(3));
            comidas.add(c);
        }
        return comidas;
    }
}
