package com.example.senai;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import androidx.appcompat.app.AppCompatActivity;

import com.example.myapplication.R;

import java.util.ArrayList;
import java.util.List;

public class Listagem extends AppCompatActivity {

    Button floating;
    private ListView ls;
    private List<Comida> comidas;
    private List<Comida> comidasFiltradas = new ArrayList<>();
    private ComidaDAO dao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.listagem);

        ls = findViewById(R.id.lvcomidas);
        dao = new ComidaDAO(this);
        comidas = dao.obterTodos();
        comidasFiltradas.addAll(comidas);

        AdapterListView adapterListView = new AdapterListView(this, comidas);
       // ArrayAdapter<Comida> adapter = new ArrayAdapter<Comida>(this, android.R.layout.simple_list_item_1, comidas);
        ls.setAdapter(adapterListView);

        findViewById(R.id.btfloat).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Listagem.this, Cadastro.class);
                startActivity(intent);
            }
        });
    }


}
