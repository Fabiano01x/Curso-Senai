package com.example.senai;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.myapplication.R;

public class Cadastro extends AppCompatActivity {

    Button bt_cancela;

    @SuppressLint("MissingInflatedId")
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.cadastro);

        bt_cancela = findViewById(R.id.bt_cancela);

        bt_cancela.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Cadastro.this, Listagem.class);
                startActivity(intent);
            }
        });
    }

    public void Inserir(View view){
        EditText edt_nome = findViewById(R.id.edt_nome);
        String nome  = edt_nome.getText().toString();
        EditText edt_preco = findViewById(R.id.edt_preco);
        String preco  = edt_preco.getText().toString();
        EditText edt_desccricao = findViewById(R.id.edt_descricao);
        String descricao  = edt_desccricao.getText().toString();

        Comida comida = new Comida(nome, preco, descricao);

        ComidaDAO dao = new ComidaDAO(this);
        long id = dao.Inserir(comida);
        Toast.makeText(this, "COMIDA INSERIDA COM ID: "+ id, Toast.LENGTH_SHORT).show();
    }
}
